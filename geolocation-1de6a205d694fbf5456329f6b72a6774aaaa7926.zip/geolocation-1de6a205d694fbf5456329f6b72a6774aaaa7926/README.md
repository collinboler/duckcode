Chrome Extension that uses LLMs to guess your onscreen location using AI computer vision (Perfect for GeoGuesser, among other things)

Download [here](https://chromewebstore.google.com/detail/geoguesser-hacker/ogjhgcaaaclhdaalliolbhibppalepkj?hl=en)

Supports OpenAI GPT-4o; more models coming soon

**3,500+ downloads and counting**
